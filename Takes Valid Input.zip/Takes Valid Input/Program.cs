using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Takes_Valid_Input
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = 0;
            var b = false;
            do
            {
                try
                {
                    Console.WriteLine("Please input a number.");
                    a = Convert.ToInt32(Console.ReadLine());
                    break;
                }
                catch (FormatException)
                {
                    b = true;
                    Console.WriteLine("Input was in an incorrect format.");
                }
            }
            while (b != false);
            Console.WriteLine($"Your input is {a}.");
            Console.ReadKey();
        }
    }
}
